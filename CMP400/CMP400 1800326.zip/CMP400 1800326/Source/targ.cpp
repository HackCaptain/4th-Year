#include "Targ.h"

#include <vector>
#include <string>

// The Procs (Process) class holds the process details, is inherited by the Targ class

    Proc::Proc() {};
    Proc::~Proc() {};

// Constructors
    // Overloaded Constructor
    Proc::Proc(std::string newname, int newpid) {
        name = newname;
        pid = newpid;
    }

    // Very verloaded constructor
    Proc::Proc(std::string newname, int newpid, int newppid) {
        name = newname;
        pid = newpid;
        ppid = newppid;
    }

// Getters
    std::string Proc::getName() {
        return name;
    }
    int Proc::getPid() {
        return pid;
    }
    int Proc::getPpid() {
        return pid;
    }

// Setters
    std::string Proc::setName(std::string newname) {
        name = newname;
    }
    int Proc::setPid(int newpid) {
        pid = newpid;
    }
    int Proc::setPpid(int newppid) {
        ppid = newppid;
    }


// Targ stuff


    Targ::Targ()
    {
    };
    Targ::~Targ()
    {
    };


//Getters
    //Get Names for the rollers
    std::string Targ::getSusName(int x) 
    {
        return terms[x];
    }
    std::string Targ::getConName(int y) 
    {
        return knowns[y];
    }

    // Get specific details about a Proc
    std::string Targ::getTargetName(int z) 
    {
        //return Targetprocs[z].getName();
        return targetnames[z];
    }
    int Targ::getTargetPid(int u) 
    {
        //return Targetprocs[u].getPid();
        return targetpids[u];
    }
    std::string Targ::getSuspectName(int v) 
    {
        //return Suspectprocs[v].getName();
        return suspectnames[v];
    }
    int Targ::getSuspectPid(int w) 
    {
        //return Suspectprocs[v].getName();
        return suspectpids[w];
    }

    // Get the size of vectors for rollers
    int Targ::getNosSus() 
    {
        return terms.size();
    }
    int Targ::getNosCon() 
    {
        return knowns.size();
    }

    // Get size of Target and Suspect Vectors
    int Targ::getNosTarget() 
    {
        return Targetprocs.size();
        //return targetnames.size();
    }
    int Targ::getNosSuspect() 
    {
        return Suspectprocs.size();
        //return suspectnames.size();
    }

    // Get the vectors of Proc objects
    std::vector<Proc> Targ::getTargets() 
    {
        return Targetprocs;
    }
    std::vector<Proc> Targ::getSuspects() 
    {
        return Suspectprocs;
    }


//Setters
    // Add a new process to look for
    void Targ::addSusName(std::string susName) 
    {
        terms.push_back(susName);
    }
    void Targ::addConName(std::string conName) 
    {
        knowns.push_back(conName);
    }

    // Add new details to the vectors, and not those inherited through Proc
    void Targ::addTargetName(std::string targetName) 
    {
        targetnames.push_back(targetName);
    }
    void Targ::addTargetPid(int targetPid) 
    {
        targetpids.push_back(targetPid);
    }
    void Targ::addSuspectName(std::string suspectName) 
    {
        suspectnames.push_back(suspectName);
    }
    void Targ::addSuspectPid(int suspectPid) 
    {
        suspectpids.push_back(suspectPid);
    }

    // Add new Procs to the Vectors of Procs
    void Targ::addTarget(Proc Tproc) 
    {
        Targetprocs.push_back(Tproc);
    }
    void Targ::addSuspect(Proc Sproc) 
    {
        Suspectprocs.push_back(Sproc);
    }

    //Resetters
    void Targ::resetTargets() 
    {
        targetnames.clear();
        targetpids.clear();
    }

    void Targ::resetSuspects() 
    {
        suspectnames.clear();
        suspectpids.clear();
    }
