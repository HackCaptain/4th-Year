#pragma once

#ifndef HELPER.H
#define HELPER.H

#include <winsock2.h>       //Socket Header -	includes scoket functions
#include <windows.h>        //Win API Header -	Windows API functions, use of T/WCHARS
#include <ws2tcpip.h>       //TCP-IP Header -	TCP-IP Defs
#include <tlhelp32.h>       //Toolhelp for windows
#include <vector>
#include <string>



//C Headers
#include <stdio.h>          //Input Output Header    
#include <math.h>           // for mouse capturing
//#include <iostream>         //Input Output Debug Header - this can be commented out for better filesize
//#include <psapi.h>    // For enuamrating procs


class Helper
{
public:

    Helper();
    ~Helper();


    const char* chardword(DWORD longint);

    const char* charint(int number);

    const char* charst(std::string input);

    bool pidcheck(const char* string);

    int strcheck(std::string s1, std::string s2);

};
#endif