#include "Helper.h"

#include <winsock2.h>       //Socket Header -	includes scoket functions
#include <windows.h>        //Win API Header -	Windows API functions, use of T/WCHARS
#include <ws2tcpip.h>       //TCP-IP Header -	TCP-IP Defs
#include <tlhelp32.h>       //Toolhelp for windows
#include <vector>
#include <string>



//C Headers
#include <stdio.h>          //Input Output Header    
#include <math.h>           // for mouse capturing
//#include <iostream>         //Input Output Debug Header - this can be commented out for better filesize
//#include <psapi.h>    // For enuamrating procs


    Helper::Helper() {};
    Helper::~Helper() {};


    const char* Helper::chardword(DWORD longint) {
        //Helper function to convert a long integer, such as dword, into a char array
        int number = (int)longint;
        std::string snumb = std::to_string(number);
        char const* pchar = snumb.c_str();

        return pchar;
    }

    const char* Helper::charint(int number) {
        // Helper function to take an integer and conver to string, then integer
        std::string snumb = std::to_string(number);
        char const* pchar = snumb.c_str();

        return pchar;
    }

    const char* Helper::charst(std::string input) {
        //Takes a string and returns a char array
        char word[512];
        strncpy(word, input.c_str(), sizeof(word));
        word[sizeof(word) - 1] = 0;

        return word;
    }

    bool Helper::pidcheck(const char* string) {
        // used by the process killer to detect if a supplied value is a number
        const int string_len = strlen(string);
        for (int i = 0; i < string_len; ++i) {
            if (!isdigit(string[i]))
                return false;
        }
        return true;
    }

    int Helper::strcheck(std::string s1, std::string s2) {
        // Used to detect if a string is inside another string
        int i, j;
        int l1 = s1.length();
        int l2 = s2.length();

        // Is this string (s1) in (s2))

        for (i = 0; i <= l1 - l1; i++) {
            for (j = 0; j < l1; j++) {
                if (s2[i + j] != s1[j])
                    break;
            }
            if (j == l1) {
                // If it is, return
                return i;
            }
        }
        return -1;

    }