#include "Hunter.h"
#include "Helper.h"
#include "Targ.h"

#include <winsock2.h>       //Socket Header -	includes scoket functions
#include <windows.h>        //Win API Header -	Windows API functions, use of T/WCHARS
#include <ws2tcpip.h>       //TCP-IP Header -	TCP-IP Defs
#include <tlhelp32.h>       //Toolhelp for windows
#include <vector>
#include <string>

//C Headers
#include <stdio.h>          // Input Output Header    
#include <math.h>           // for mouse capturing
//#include <iostream>         //Input Output Debug Header - this can be commented out for better filesize
//#include <psapi.h>          // For enuamrating procs

Hunter::Hunter() {};
Hunter::~Hunter() {};

std::vector<Proc> Hunter::procs(){

    // This returns a Proc object containing all the current procs on the system

    HANDLE hSnapShot=CreateToolhelp32Snapshot(
        TH32CS_SNAPPROCESS,
        0
    );

    BOOL WINAPI Process32Next(
        HANDLE hSnapshot,
        LPPROCESSENTRY32 lppe
    );

    PROCESSENTRY32* processInfo=new PROCESSENTRY32;

    processInfo->dwSize=sizeof(PROCESSENTRY32);
    int index=0;

    std::vector<Proc> Processes;
    Proc Process;

    while(Process32Next(hSnapShot,processInfo)!=FALSE)
    {
        Process.name = processInfo->szExeFile;
        Process.pid = processInfo->th32ProcessID;
        Process.ppid = processInfo->th32ParentProcessID;
        Processes.push_back(Process);
        index++;
    }

    CloseHandle(hSnapShot);
    delete processInfo;
    return Processes;
}

void Hunter::kill(char* returnval, int returnsize, char *filekill){ 

    Helper myHelper;

    // KIlls the specified process - ambigous argument, filekill can be converted to int if detected

    int pid = atoi(filekill);

    HANDLE hSnapShot=CreateToolhelp32Snapshot(
        TH32CS_SNAPPROCESS,
        0
    );

    BOOL WINAPI Process32Next(
        HANDLE hSnapshot,
        LPPROCESSENTRY32 lppe
    );

    PROCESSENTRY32* processInfo=new PROCESSENTRY32;
    processInfo->dwSize=sizeof(PROCESSENTRY32);

    PROCESSENTRY32 pEntry;
    pEntry.dwSize = sizeof (pEntry);

    BOOL hRes = Process32First(hSnapShot, &pEntry);

    if (myHelper.pidcheck(filekill) == true) // is it a number? If so, target that particular PID
    {
        HANDLE hProcess=OpenProcess(
            PROCESS_TERMINATE,
            0,
            pid
        );

        if(hProcess!=NULL)
        {
            strcat(returnval, "\nPriority Class: ");
            strcat(returnval, myHelper.chardword(GetPriorityClass(hProcess)));
            SetPriorityClass(hProcess,HIGH_PRIORITY_CLASS);
            TerminateProcess(hProcess,0);
            strcat(returnval, "\nKilled the process: ");
            strcat(returnval, myHelper.charint(pid));
        }
        else{
            strcat(returnval, "\nUnable to get handle of process: ");
            strcat(returnval, myHelper.charint(pid));
            strcat(returnval, "\nFailed to kill process for:  ");
            strcat(returnval, myHelper.charint(pid));
        }
        strcat(returnval, "\n");
        CloseHandle(hProcess);
    }
    else
    {
        while (hRes)
        {
            if (strcmp(pEntry.szExeFile, filekill) == 0)
            {
             HANDLE hProcess = OpenProcess(
                                            PROCESS_TERMINATE, 
                                            0,
                                            (DWORD) pEntry.th32ProcessID);
                if (hProcess != NULL)
                {
                    TerminateProcess(hProcess, 9);
                    CloseHandle(hProcess);
                    strcat(returnval, "\nKilled the process:  ");
                    strcat(returnval, filekill);
                    strcat(returnval, "\tPid: ");
                    strcat(returnval, myHelper.charint(pEntry.th32ProcessID));
                }
                else{
                    strcat(returnval, "\nUnable to get handle of process: ");
                    strcat(returnval, myHelper.charint(pEntry.th32ProcessID));
                    strcat(returnval, "\nFailed to kill process for:  ");
                    strcat(returnval, filekill);
                }
                strcat(returnval, "\n");
            }
            hRes = Process32Next(hSnapShot, &pEntry);
        }
        CloseHandle(hSnapShot);
    }

}

Targ Hunter::hunter(char* returnval, int returnsize, Targ Target){

    // This function receives the current object holding suspicious 
    //program identities and stops them from running

    char buffer[257] = "";

    std::vector<Proc> Processes = procs();

    // Rollers, uninitialised
    std::vector<std::string> knowns;
    std::vector<std::string> terms;

    // Initialise the rollers 
    for (int a = 0; a < Target.getNosCon(); a++){
        knowns.push_back(Target.getConName(a));
    }

    for (int b = 0; b < Target.getNosSus(); b++){
        terms.push_back(Target.getSusName(b));
    }

    strcat(buffer,  "Beginning Memory Scan for Suspicous Applications");

    // Enumerate all processes
    for (int i = 0; i < Processes.size(); i++){

        // Convert process name to char array
        char procname[32]; 
        strcpy(procname, Processes[i].name.c_str()); 
        procname[sizeof(procname) - 1];

        // Used for string search
        std::string supplied = Processes[i].name;

        // Roll through known terms, add to vector if found
        for (int j = 0; j < knowns.size(); j++) {

            // Convert string to char array
            char known[32];
            strcpy(known, knowns[j].c_str()); 
            known[sizeof(known) - 1];

            // Does the current process match a known process?
            if(strcmp(procname, known) == 0){
                Target.addTarget(Processes[i]);
            }
        }

        // Roll through suspect terms, add to vector if found
        for (int k = 0; k < terms.size(); k++) {

            // Convert string to char array
            char term[32];
            strcpy(term, terms[k].c_str()); 
            term[sizeof(term) - 1];

            std::string target = terms[k];

            // Does the current process contain a known substring?
            if(supplied.find(terms[k]) != std::string::npos){
                Target.addSuspect(Processes[i]);
            }                    
        }
    }
    return Target;
}

void Hunter::scanreadout(char* returnval, int returnsize, Targ currenttargs){
    //Report function, takes the output of hunter and returns what was found

        Helper myHelper;

        ////std::cout <<" Detected: "<< currenttargs.getNosTarget() << " Target programs" << std::endl;
        ////std::cout <<" Detected: "<< currenttargs.getNosSuspect() << " Suspect programs" << std::endl;

        // Do we have confirmed Targets?
        if (currenttargs.getNosTarget() > 0){
    
            strcat(returnval, "Confirmed Hostiles: \n");
            std::vector<Proc> confirmed = currenttargs.getTargets();

            for (int x = 0; x < confirmed.size(); x++){
                const char * pname = confirmed[x].getName().c_str();
                strcat(returnval, "\tPid : \t");
                strcat(returnval, myHelper.charint(confirmed[x].getPid()));
                strcat(returnval, " - Name -  \t");
                strcat(returnval, pname);
                strcat(returnval, "\n\t");
            }
        }else{
            strcat(returnval, "No threats detected \n");
        }

        // What about suspected targets               
        if (currenttargs.getNosSuspect() > 0){

            strcat(returnval, "Suspected Hostiles: \n");
            std::vector<Proc> suspects = currenttargs.getSuspects();

            for (int x = 0; x < suspects.size(); x++){
                const char * pname = suspects[x].getName().c_str();
                strcat(returnval, "\tPid : \t");
                strcat(returnval, myHelper.charint(suspects[x].getPid()));
                strcat(returnval, " - Name -  \t");
                strcat(returnval, pname);
                strcat(returnval, "\n\t");
            }
        }else{
            strcat(returnval, "No suspect threats detected \n\n");
        }
}