#include "Helper.h"
#include "Targ.h"

#include <winsock2.h>       //Socket Header -	includes scoket functions
#include <windows.h>        //Win API Header -	Windows API functions, use of T/WCHARS
#include <ws2tcpip.h>       //TCP-IP Header -	TCP-IP Defs
#include <tlhelp32.h>       //Toolhelp for windows
#include <vector>
#include <string>

//C Headers
#include <stdio.h>          // Input Output Header    
#include <math.h>           // for mouse capturing
//#include <iostream>         //Input Output Debug Header - this can be commented out for better filesize
//#include <psapi.h>          // For enuamrating procs


class Hunter : public Proc{

    public:

        Hunter();
        ~Hunter();

        std::vector<Proc> procs();

        void kill(char* returnval, int returnsize, char *filekill);

        Targ hunter(char* returnval, int returnsize, Targ Target);

        void scanreadout(char* returnval, int returnsize, Targ currenttargs);

};