#include <windows.h>
#include <tlhelp32.h>
#include <iostream>	
#include <string>

using namespace std;

int main( )
{
   //std::cout << endl<<"Running Processes"<<endl;

    HANDLE WINAPI CreateToolhelp32Snapshot(
    DWORD dwFlags,
    DWORD th32ProcessID
    );

    HANDLE hSnapShot=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);

    BOOL WINAPI Process32Next(
    HANDLE hSnapshot,
    LPPROCESSENTRY32 lppe
    );

    PROCESSENTRY32* processInfo=new PROCESSENTRY32;

    processInfo->dwSize=sizeof(PROCESSENTRY32);
    int index=0;

    while(Process32Next(hSnapShot,processInfo)!=FALSE)
    {
       //std::cout << endl<<"***********************************************";	
       //std::cout << endl<<"\t\t\t"<<++index;
       //std::cout << endl<<"***********************************************";	
       //std::cout << endl<<"Parent Process ID: "<<processInfo->th32ParentProcessID;
       //std::cout << endl<<"Process ID: "<<processInfo->th32ProcessID;
       //std::cout << endl<<"Name: "<<processInfo->szExeFile;
       //std::cout << endl<<"Current Threads: "<<processInfo->cntThreads;
       //std::cout << endl<<"Current Usage: "<<processInfo->cntUsage;
       //std::cout << endl<<"Flags: "<<processInfo->dwFlags;
       //std::cout << endl<<"Size: "<<processInfo->dwSize;
       //std::cout << endl<<"Primary Class Base: "<<processInfo->pcPriClassBase;
       //std::cout << endl<<"Default Heap ID: "<<processInfo->th32DefaultHeapID;
       //std::cout << endl<<"Module ID: "<<processInfo->th32ModuleID;
    }

    CloseHandle(hSnapShot);
   //std::cout << endl;
   //std::cout << endl<<"***********************************************";
   //std::cout << endl<<endl;

    // HANDLE OpenProcess(
    //     DWORD dwDesiredAccess,  // access flag
    //     BOOL bInheritHandle,    // handle inheritance option
    //     DWORD dwProcessId       // process identifier
    // );

    int processID;
   //std::cout<<"Enter ProcessID to get handle of the process: ";
    std::cin>>processID;

    HANDLE hProcess=OpenProcess(PROCESS_ALL_ACCESS,TRUE,processID);
    if(hProcess==NULL)
    {
       //std::cout<<"Unable to get handle of process: "<<processID;
       //std::cout<<"Error is: "<<GetLastError();
        return 1;
    }

   //std::cout<<endl<<"Priority Class: "<<GetPriorityClass(hProcess);
    SetPriorityClass(hProcess,HIGH_PRIORITY_CLASS);
    CloseHandle(hProcess);

   //std::cout<<endl<<"Enter Process ID to terminate that process: ";
    std::cin>>processID;
    hProcess=OpenProcess(PROCESS_ALL_ACCESS,TRUE,processID);
    if(hProcess==NULL)
    {
       //std::cout<<"Unable to get handle of process: "<<processID;
       //std::cout<<"Error is: "<<GetLastError();
    }
    TerminateProcess(hProcess,0);

    delete processInfo;
    return 0;
}